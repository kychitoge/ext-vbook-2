load('config.js');

// page.js - returns list of pages for TOC pagination
function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:www\.)?([^\/]+)/, BASE_URL);
    
    var response = fetch(url);
    if (!response.ok) return Response.error("Cannot load");
    
    var doc = response.text();
    var match = doc.match(/postid-(\d+)/);
    var parentId = match ? match[1] : null;
    
    if (!parentId) return Response.success([url]);
    
    // Check API for pagination
    var apiResponse = fetch(BASE_URL + "/wp-admin/admin-ajax.php", {
        method: "POST",
        headers: {"Content-Type": "application/x-www-form-urlencoded", "X-Requested-With": "XMLHttpRequest"},
        body: "action=nt_load_chapters&parent_id=" + parentId + "&page=1"
    });
    
    if (!apiResponse.ok) return Response.success([url]);
    
    var html = apiResponse.html() + "";
    if (html.indexOf("loadChapters") === -1) {
        return Response.success([url]);
    }
    
    // Has 14 pages
    var pages = [];
    for (var i = 1; i <= 14; i++) {
        pages.push(url + "?chapter_page=" + i);
    }
    
    return Response.success(pages);
}