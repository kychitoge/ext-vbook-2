load('config.js');
function execute(url) {
    url = url.replace(/^(?:https?:\/\/)?(?:[^@\n]+@)?(?:www\.)?([^:\/\n?]+)/img, BASE_URL);
    var response = fetch(url);
    if (!response.ok) return Response.error("Cannot load: " + response.status);
    
    var doc = response.html();
    var chapters = [];
    var seenUrls = {};
    
    doc.select("a[href]").forEach(function(el) {
        var text = (el.text() || "").trim();
        var href = (el.attr("href") || "").trim();
        
        if (text.indexOf("Chương") > -1 && href.indexOf("/chuong-") > -1 && href.indexOf(url) > -1) {
            if (!seenUrls[href]) {
                seenUrls[href] = true;
                chapters.push({
                    name: text,
                    url: href,
                    host: BASE_URL
                });
            }
        }
    });
    
    if (chapters.length === 0) {
        return Response.error("No chapters found");
    }
    
    chapters.sort(function(a, b) {
        var numA = a.name.match(/Chương\s*(\d+)/);
        var numB = b.name.match(/Chương\s*(\d+)/);
        var nA = numA ? parseInt(numA[1]) : 0;
        var nB = numB ? parseInt(numB[1]) : 0;
        return nA - nB;
    });
    
    return Response.success(chapters);
}